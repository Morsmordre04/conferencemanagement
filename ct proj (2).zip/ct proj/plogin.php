<?php
session_start();
require_once('connect.php');
if(isset($_POST) & !empty($_POST))
{
$name = $_POST['uname'];
$psw = $_POST['psw'];
$sql="SELECT * FROM participants WHERE Name='$name' AND password='$psw'";
$result=mysqli_query($connection,$sql);
$count=mysqli_num_rows($result);
if($count==1)
{$_SESSION['Name']=$name;
readfile('upload.html');}
else
{ readfile('plogin.html') ;}
}
?>