<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST))
{
$name = $_POST['name'];
$dob = $_POST['dob'];
$fathername = $_POST['fathername'];
$college = $_POST['clgname'];
$year = $_POST['year'];
$department = $_POST['department'];
$email = $_POST['email'];
$psw = $_POST['psw'];
$sql="INSERT INTO participants VALUES ('$name','$dob','$fathername' ,'$college','$year','$department' ,'$email','$psw','','','')";
$result=mysqli_query($connection,$sql);
if($result)
{readfile('plogin.html');}
else
readfile('ppsignup.html');
}
?>