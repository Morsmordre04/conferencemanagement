<?php
session_start();
require_once('connect.php');
if(isset($_POST) & !empty($_POST))
{
$name = $_POST['uname'];
$psw = $_POST['psw'];
$sql="SELECT * FROM attenders WHERE name='$name' AND psw='$psw'";
$result=mysqli_query($connection,$sql);
$count=mysqli_num_rows($result);
if($count==1)
{$_SESSION['name']=$name;
readfile('aacc.html');}
else
{ readfile('alogin.html'); }
}
?>