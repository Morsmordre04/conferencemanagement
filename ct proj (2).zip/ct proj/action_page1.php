<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST))
{
$name = $_POST['name'];
$dob = $_POST['dob'];
$email = $_POST['email'];
$psw = $_POST['psw'];
$college = $_POST['clgname'];
$year = $_POST['year'];
$sql="INSERT INTO attenders VALUES ('$name','$dob ','$email ','$psw','$college','$year')";
$result=mysqli_query($connection,$sql);
if($result)
{readfile('aacc.html');}
else
readfile('alogin.html');;
}
?>
