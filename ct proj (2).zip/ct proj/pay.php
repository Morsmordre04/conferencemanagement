<?php
session_start();
require_once('connect.php');
if(isset($_POST) & !empty($_POST))
{
$name = $_POST['name'];
$cname = $_POST['cardname'];
$cardnumber= $_POST['cardnumber'];
$amt = $_POST['amt'];
$sql="INSERT INTO paid VALUES ('$name','$cname ','$cardnumber ','$amt')";
$result=mysqli_query($connection,$sql);
if($result)
{readfile('frontpage.html');;}
else
echo "fail";
}
?>