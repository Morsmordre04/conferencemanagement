-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2018 at 05:10 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `participants`
--

-- --------------------------------------------------------

--
-- Table structure for table `attenders`
--

CREATE TABLE `attenders` (
  `name` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(20) NOT NULL,
  `psw` varchar(20) NOT NULL,
  `clgname` varchar(20) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attenders`
--

INSERT INTO `attenders` (`name`, `dob`, `email`, `psw`, `clgname`, `year`) VALUES
('monisha', '2018-09-03', 'monishaasaikkannu@gm', 'sss', 'msec', 3),
('', '2018-09-04', 'monishamoni1@yahoo.i', 'sss', '', 0),
('', '2018-09-04', 'monishamoni1@yahoo.i', 'sss', '', 0),
('', '2018-09-04', 'monishamoni1@yahoo.i', 'sss', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `paid`
--

CREATE TABLE `paid` (
  `participant name` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `card number` bigint(20) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paid`
--

INSERT INTO `paid` (`participant name`, `name`, `card number`, `amount`) VALUES
('moni', 'moni ', 11111111111, 23),
('monisha', 'monisha ', 0, 0),
('', ' ', 0, 0),
('', ' ', 0, 0),
('', ' ', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `participants`
--

CREATE TABLE `participants` (
  `Name` varchar(100) NOT NULL,
  `DOB` date NOT NULL,
  `father's name` varchar(100) NOT NULL,
  `COLLEGE NAME` varchar(100) NOT NULL,
  `year` varchar(5) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `uploadfile` varchar(100) NOT NULL,
  `papername` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participants`
--

INSERT INTO `participants` (`Name`, `DOB`, `father's name`, `COLLEGE NAME`, `year`, `dept`, `email`, `password`, `uploadfile`, `papername`, `status`) VALUES
('varsha', '1998-09-02', 'kumar', 'msec', '3', 'cse', 'sample@gmail.com', 'sample', 'ibrahim.pdf', ' ml', 's'),
('moni', '1998-09-23', 'asai', 'ssn', '3', 'cse', 'monishaasaikkannu@gmail.com ', 'sss', 's', 's', 's'),
('moni', '1998-09-23', 'asai', 'ssn', '3', 'cse', 'monishaasaikkannu@gmail.com ', 'sss', 's', 's', 's');

-- --------------------------------------------------------

--
-- Table structure for table `selected_participants`
--

CREATE TABLE `selected_participants` (
  `name` varchar(100) NOT NULL,
  `topic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selected_participants`
--

INSERT INTO `selected_participants` (`name`, `topic`) VALUES
('sri', ' ');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
