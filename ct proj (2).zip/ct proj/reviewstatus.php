<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "participants";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$query =mysqli_query ($conn,"SELECT * FROM participants WHERE status='s'");
$rowcount = mysqli_num_rows($query);
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 160px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    padding-top: 20px;
}

.sidenav a {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.main {
    margin-left: 160px; /* Same as the width of the sidenav */
    font-size: 24px; /* Increased text to enable scrolling */
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
}
.button {
    background-color: #99cc00;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;

}
    table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color: #fff;
}
table#t01 th {
    background-color: black;
    color: white;
}
</style>
</head>
<body>

<div class="sidenav">
  <a href="#about">Schedule</a>
  <a href="#services">Rules</a>
  <a href="#clients">Review Status</a>
  <a href="#clients">Payment</a>
</div>

<div class="main">
  <h4>Schedule</h4>
 <h4>Sunday, 
 April 22
 10:30 - 12:45 p.m.:	Registration
 12:00 - 12:30 p.m.:First Timer Welcome
 1:00 - 2:30 p.m.  :Lunch & Keynote Speaker
</h4>
</div>
<div class="main">
  <h2>Rules</h2>
    <p>1.A Team can have maximum of 3 members<br>
    2.The topic must be related to the theme<br>
    3.Each team will have 15 mins to present on their topic<br></p>

</div>
 <div class="main">
  <h2>Review Status[selected student]</h2>
     <form  method="post">
     <table id="t01">
  <tr>
      <th>name</th>
    <th>paper</th>
    
  </tr>
         <?php
for($i=1;$i<=$rowcount;$i++)
{$row=mysqli_fetch_array($query);
 $name= $row["Name"];
  $pname= $row["papername"];

$sql="INSERT INTO selected_participants VALUES ('$name','$pname ')";
?>
<tr>
<td><?php echo $row["Name"]?></td>
<td><?php echo $row["papername"]?></td>
</tr>
<?php
}
?>


     </table>
       
     </form>
  
<form action="payment1.html" onsubmit="if(document.getElementById('agree').checked) { return true; } else { alert('Please indicate that you have read and agree to the Terms and Conditions and Privacy Policy'); return false; }">

<input type="checkbox" name="checkbox" value="check" id="agree" /> I have read and agree to the Terms and Conditions.
<br>
    <a href="payment1.html"><button type="submit" class="button"  href="payment1.html">Payment</button>
    </a>
</form>
</div>

</body>
</html> 