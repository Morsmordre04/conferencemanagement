<?php
require_once('connect.php');
if(isset($_POST) & !empty($_POST))
{
$name = $_POST['Name'];
    $namenam = trim($name);
    
$projecttitle = $_POST['projecttitle'];
    $allow =array('pdf');
$temp=explode(".",$_FILES['pdf1']['name']);
$extension=end($temp);
$upload_file=$_FILES['pdf1']['name'];
move_uploaded_file($_FILES['pdf1']['tmp_name'],"upload/".$_FILES['pdf1']['name']);
//$sql="INSERT INTO participants  VALUES ('', '', '', '', '', '', '', '', '$upload_file', '$projecttitle', '') ";
    
    
    
//    $sql1 = "UPDATE participants SET papername='$projecttitle' WHERE Name='$name'";
    
    $sql1 = "UPDATE participants SET papername = '$projecttitle',uploadfile='$upload_file' WHERE Name = '$namenam'";


    echo $sql1;
$result=mysqli_query($connection,$sql1);
if($result)
{readfile('upload.html');
 }
else
echo "fail";
}
?>


