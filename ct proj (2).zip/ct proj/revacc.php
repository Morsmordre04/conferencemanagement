<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "participants";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$query =mysqli_query ($conn,"SELECT * FROM participants");
$rowcount = mysqli_num_rows($query);
?>
<html>
<style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color: #fff;
}
table#t01 th {
    background-color: black;
    color: white;
}
</style>
<center>
<body>
<h2>STUDENTS WHO SUBMITTED THEIR PAPER</h2>
</center>
   <form  method= "POST" >
<table id="t01"><tr><th>NAME</th><th>PAPER NAME</th><th>STATUS</th></tr>

<?php
for($i=1;$i<=$rowcount;$i++)
{$row=mysqli_fetch_array($query);

?>
<tr>
<td><?php echo $row["Name"]?></td>
<td><?php echo $row["papername"]?></td>
<td><input type="checkbox" value="yes">selected</td>
</tr>
<?php
}
?>

</body>
</table>
<center>
 <button onclick="myFunction()">submit</button>

<p id="demo"></p>

<script>
function myFunction() {
  
   if (confirm("conform submit?thank you")) {
      window.open("frontpage.html");
    } else {
window.open("revacc.html");
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>
    </center>
</form>
</html>